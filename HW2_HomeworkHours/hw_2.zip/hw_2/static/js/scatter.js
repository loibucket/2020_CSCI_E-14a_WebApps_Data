/*
'use strict';

// IIFE
(function () {

    // Init data
    let data = [];

    // Fetch json data
    d3.json('/load_data', (d) => {

        // Parse
        return d.forEach(function (d) {
            d.experience_yr = +d.experience_yr;
            d.hw1_hrs = +d.hw1_hrs;
            d.age = +d.age;
        })
    }).then((d) => {

        // Redefine data
        data = d['users'];

        createVis();
    }).catch((err) => {

        console.error(err);
    });

   
    function createVis() {

        // Get svg
        const svg = d3.select('#scatter');

        // Config
        const margin = {'top': 25, 'right': 30, 'bottom': 50, 'left': 64};
        const width = +svg.attr('width') - (margin.right + margin.left);
        const height = +svg.attr('height') - (margin.top + margin.bottom);

        // Create and position container
        const container = svg.append('g')
            .attr('class', 'container')
            .style('transform', `translate(${margin.left}px, ${margin.top}px)`);

        //  Scales
        const scX = d3.scaleLinear()
            .domain(d3.extent(data, (d) => {
                return d.experience_yr;
            })).nice()
            .range([0, width]);

        const scY = d3.scaleLinear()
            .domain(d3.extent(data, (d) => {
                return d.hw1_hrs;
            })).nice()
            .range([height, 0]);

        const scRad = d3.scaleSqrt()
            .domain(d3.extent(data, (d) => {
                return d.age;
            })).nice()
            .range([2, 5]);


        // Generate bubbles
        

        // Generate x- and y-axis
        

        // Set xLabel and yLabel
        

    }

})();

*/