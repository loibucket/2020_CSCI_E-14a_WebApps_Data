#import libraries

#import Heroku

app = Flask(__name__)
app.secret_key = "cscie14a-hw3"

app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://localhost/hw3_db'

db.init_app(app)

#routes

if __name__ == "__main__":
    app.run(debug=True)
