#Import CSV to Postgresql 

import psycopg2
import pandas as pd