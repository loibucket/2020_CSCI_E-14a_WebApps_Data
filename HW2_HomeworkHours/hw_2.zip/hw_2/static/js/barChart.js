/*
'use strict';

// IIFE
(function () {

    // Init data
    let data = [];

    // Fetch json data
    d3.json('/load_data', (d) => {

        return d;
    }).then((d) => {

        // Redefine data
        data = d['users'];

        createVis();
    }).catch((err) => {

        console.error(err);
    });


    // Function createVis

    function createVis() {

        // Get svg
        const svg = d3.select('#barChart');

        // Config
        const margin = {'top': 25, 'right': 54, 'bottom': 50, 'left': 10};
        const width = +svg.attr('width') - (margin.right + margin.left);
        const height = +svg.attr('height') - (margin.top + margin.bottom);

        // Create and position container
        const container = svg.append('g')
            .attr('class', 'container')
            .style('transform', `translate(${margin.left}px, ${margin.top}px)`);

        // Set ageMap
       

        // X Scale
        

        // Histogram and bins
        

        // Y Scale
        

        // Config transition
        

        // Create bars
       

        // Create rects
      

        // Add y-label
        

        // Add x-axis
        

        // Add x-label
        

    }


})();

*/